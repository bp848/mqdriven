
import React from 'react';
import PlaceholderPage from '../PlaceholderPage';

const ReceiptManagementPage: React.FC = () => {
    return (
        <PlaceholderPage title="領収書管理" />
    );
};

export default ReceiptManagementPage;
